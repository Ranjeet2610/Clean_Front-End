
// export const APIURL = "http://18.134.128.178:4002/api/"
export const APIURL = "http://3.108.46.86:4000/api/"

// export const APIURL = "http://65.0.100.189:4002/api/"

